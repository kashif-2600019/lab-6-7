const express = require("express");
const app = express();

app.use(express.json());

app.get("/", function (req, res) {
    res.send("HELLOW MY API IS WORKING");
});

let student = [
    { id: 1, name: "ali", email: "ali@mail.com", program: "BSCS" },
    { id: 2, name: "sara", email: "sara@mail.com", program: "BSCS" }
];

let nextId = 3;

app.get("/students", function (req, res) {
    res.json(student);
});

app.get("/students/:id", function (req, res) {
    const id = Number(req.params.id);

    const foundStudent = student.find(function (s) {
        return s.id === id;
    });

    if (!foundStudent) {
        return res.status(404).json({
            message: "Student not found"
        });
    }

    res.json(foundStudent);
});

app.post("/students", function (req, res) {
    const { name, email, program } = req.body || {};

    if (!name || !email || !program) {
        return res.status(400).json({
            message: "All fields are required"
        });
    }

    const newStudent = {
        id: nextId++,
        name: name,
        email: email,
        program: program
    };

    student.push(newStudent);

    res.status(201).json(newStudent);
});

app.listen(3000, function () {
    console.log("Running at http://localhost:3000");
});